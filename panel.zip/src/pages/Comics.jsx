import React from "react";
import { Link } from "react-router-dom";
import "../styles/categoryView.css"
import placeholder from "../assets/imgs/istockphoto-1147544807-612x612.jpg";

function Comics() {
    return (
      <div className="manga-global">
        Comics
      </div>
    );
  }
  
  export default Comics;
  