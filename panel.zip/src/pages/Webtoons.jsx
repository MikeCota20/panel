import React from "react";
import { Link } from "react-router-dom";
import "../styles/categoryView.css"
import placeholder from "../assets/imgs/istockphoto-1147544807-612x612.jpg";

function Webtoons() {
    return (
      <div className="manga-global">
        Webtoons 
      </div>
    );
  }
  
  export default Webtoons;